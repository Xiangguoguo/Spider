# -*- coding: utf-8 -*-
import scrapy
import re
import requests
import csv
import codecs
from mySpider.items import MyspiderItem

class SpidermanSpider(scrapy.Spider):
    name = 'spiderMan'
    start_urls = ['http://202.119.85.163/open/DsDir_View.aspx?yxsh=103']

    def parse(self, response):
        # print response.text
        pattern=re.compile('<a.*?class="none".*?href="(.*?)".*?target="_blank">(.*?)</a>',re.S)
        teachers=re.findall(pattern,response.text)
        print (len(teachers))
        url=""
        for teacher in teachers:
            if teacher[0][0]=='T':
                url='http://202.119.85.163/open/'+teacher[0]
            else:
                url=teacher[0]
            response_inner=requests.get(url)
            pattern=re.compile('<td class="tb_line" style="width: 70px; text-align: center">.*?left">\s+(.*?)\s+</td>'
                   '.*?</td>.*?</td>.*?tb_line">\s+(.*?)\s+</td>.*?</td>.*?</td>.*?</td>.*?</td>.*?</td>'
                   '.*?</td>.*?</td>.*?</td>.*?</td>.*?>\s(.*?)\s</td>.*?</td>.*?>\s+(.*?)\s+</td>'
                   '.*?Email.*?</td>.*?>\s+(.*?)\s+</td>.*?</td>.*?</td>'
                   '.*?<td class="tb_line" style="text-align: left;" colspan="5">\s+(.*?)\s+</td>',re.S)
            results=re.findall(pattern,response_inner.text)
            for result in results:
                item=MyspiderItem()
                item['name']=result[0].strip()
                item['birth']=result[1].strip()
                item['degree']=result[2].strip()
                item['status']=result[3].strip()
                item['email']=result[4].strip()
                item['direction']=result[5].strip()
                yield item
                # print (item['name'],item['birth'],item['degree'],item['status'],item['email'],item['direction'])

