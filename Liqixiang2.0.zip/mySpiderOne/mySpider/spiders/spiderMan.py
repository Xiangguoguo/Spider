# -*- coding: utf-8 -*-
import scrapy
import re
import requests
import csv
import codecs
from mySpider.items import MyspiderItem

class SpidermanSpider(scrapy.Spider):
    name = 'spiderMan'
    start_urls = ['http://202.119.85.163/open/DsDir_View.aspx?yxsh=103']

    def parse(self, response):
        # print response.text
        pattern=re.compile('<a.*?class="none".*?href="(.*?)".*?target="_blank">(.*?)</a>',re.S)
        teachers=re.findall(pattern,response.text)
        print (len(teachers))
        url=""
        for teacher in teachers:
            if teacher[0][0]=='T':
                url='http://202.119.85.163/open/'+teacher[0]
            else:
                url=teacher[0]
            response_inner=requests.get(url)
            pattern=re.compile('<td class="tb_line" style="width: 70px; text-align: center">.*?left">(.*?)</td>'
                   '.*?</td>.*?</td>.*?tb_line">(.*?)</td>.*?</td>.*?</td>.*?</td>.*?</td>.*?</td>'
                   '.*?</td>.*?</td>.*?</td>.*?</td>.*?>\s(.*?)\s</td>.*?</td>.*?<td class="tb_line">(.*?)</td>'
                   '.*?Email.*?</td>.*?>(.*?)</td>.*?</td>.*?</td>'
                   '.*?<td class="tb_line" style="text-align: left;" colspan="5">(.*?)</td>',re.S)
            results=re.findall(pattern,response_inner.text)
            for result in results:
                item=MyspiderItem()
                item['a_name']=result[0].strip()
                item['b_birth']=result[1].strip()
                item['c_degree']=result[2].strip()
                item['d_status']=re.sub('<.*?>','',result[3].strip())
                item['e_email']=re.sub('<.*?>','',result[4].strip())
                item['f_direction']=re.sub('<.*?>|\s+','',result[5].strip())
                yield item
                # print (item['a_name'],item['b_birth'],item['c_degree'],item['d_status'],item['e_email'],item['f_direction'])

