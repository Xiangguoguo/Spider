# coding:utf-8
__coder__ = '李启祥'
from scrapy.cmdline import execute
execute(['scrapy','crawl','spiderMan'])